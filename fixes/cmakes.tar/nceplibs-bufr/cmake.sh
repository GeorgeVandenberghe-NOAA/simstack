rm -rf build ; mkdir build ; cd build
cmake .. -DCMAKE_INSTALL_PREFIX=$GSILIBS                 -DENABLE_TESTS=OFF -DOPENMP=OFF -DBUILD_TESTS=OFF
 make  -f CMakeFiles/Makefile2 all 
 make    install


