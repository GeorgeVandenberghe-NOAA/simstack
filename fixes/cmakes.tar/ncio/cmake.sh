rm -rf build ; mkdir build ; cd build
cmake .. -DCMAKE_INSTALL_PREFIX=$GSILIBS -DENABLE_TESTS=OFF -DOPENMP=OFF
make VERBOSE=1 install

