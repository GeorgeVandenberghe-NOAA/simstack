rm -rf build ; mkdir build ; cd build
  cmake -DCMAKE_INSTALL_PREFIX=$GSILIBS  ..
make VERBOSE=1 install

