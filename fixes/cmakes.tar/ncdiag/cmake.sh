rm -rf build ; mkdir build ; cd build
#cmake .. -DCMAKE_INSTALL_PREFIX=/lfs/h2/emc/stmp/gwv/pkg -DENABLE_TESTS=OFF -DOPENMP=OFF
cmake .. -DCMAKE_INSTALL_PREFIX=$GSILIBS  -DENABLE_TESTS=OFF -DOPENMP=OFF
make install
